import { Input as InputPrimitive } from '@base-ui/react/input'
import { cn } from 'cn'
import * as React from 'react'

function Input({ className, type, ...props }: React.ComponentProps<'input'>) {
	return (
		<InputPrimitive
			type={type}
			data-slot="input"
			className={cn(
				'h-8 relative w-full rounded-lg border border-input bg-transparent px-2.5 py-1  text-base transition-colors outline-none file:inline-flex file:font-medium file:text-foreground placeholder:text-muted-foreground focus-visible:border-ring aria-invalid:ring-3 focus-visible:ring-ring/50 disabled:pointer-events-none disabled:cursor-not-allowed disabled:bg-input/50 disabled:opacity-50 aria-invalid:border-destructive  aria-invalid:ring-destructive/20 md:text-sm dark:bg-input/30 dark:disabled:bg-input/80 dark:aria-invalid:border-destructive/50 dark:aria-invalid:ring-destructive/40',
				className
			)}
			{...props}
		/>
	)
}

export { Input }
