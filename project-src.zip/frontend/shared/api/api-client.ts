
const API_URL =
  process.env.NEXT_PUBLIC_API_URL ??
  (process.env.NODE_ENV === 'production'
    ? '/api'
    : 'http://localhost:3000/api')
    
export default async function ApiClient<T>(
  endpoint: string,
  options?: { method?: string; body?: Record<string, unknown>; auth?: boolean }
): Promise<T> {
  const headers: Record<string, string> = {
    'Content-Type': 'application/json'
  }

  const auth = options?.auth

  // if auth not false, add authorization header
  if (auth !== false) {
    const token = localStorage.getItem('access_token')

    if (token) {
      headers.Authorization = `Bearer ${token}`
    }
  }

  // make the request
  const response = await fetch(`${API_URL}${endpoint}`, {
    method: options?.method || 'GET',
    headers,
    body: options?.body ? JSON.stringify(options.body) : undefined
  })

  // Check on the error
  if (!response.ok) {
    const errorData = await response.json()

    throw new Error(errorData.message)
  }

  return response.json()
}
